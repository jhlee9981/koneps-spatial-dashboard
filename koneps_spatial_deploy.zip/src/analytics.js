/**
 * 나라장터 공간정보 사업 데이터 분석 및 통계 집계 엔진
 * [5억 미만 중점 분석 세그먼트 포함]
 */

function calculateAnalytics(projects) {
  if (!projects || projects.length === 0) {
    return {
      summary: { totalCount: 0, totalBudget: 0, avgBudget: 0, maxBudget: 0, successCount: 0, pendingCount: 0 },
      under500M: { totalCount: 0, totalBudget: 0, avgBudget: 0, smallBizRatio: 0, buckets: [] },
      monthly: [],
      categories: [],
      orgTypes: [],
      topAgencies: [],
      budgetRanges: [],
      contractMethods: [],
      topThemes: [],
      winStats: { awardedCount: 0, avgSuccRate: 0, topWinners: [] }
    };
  }

  const totalCount = projects.length;
  let totalBudget = 0;
  let maxBudgetProj = null;
  let successCount = 0;
  let totalSuccRateSum = 0;
  let succRateCount = 0;

  // 5억 미만 전용 집계 변수
  let under500Count = 0;
  let under500Budget = 0;
  let under100Count = 0; // 1억 미만 소액
  let under50Count = 0;  // 5천만 미만 초소액 수의

  const under500Buckets = [
    { label: "5천만 미만", min: 0, max: 50000000, count: 0, budget: 0, desc: "초소액 / 수의계약 중심" },
    { label: "5천만 ~ 1억", min: 50000000, max: 100000000, count: 0, budget: 0, desc: "소액 입찰 / 기초 유지보수" },
    { label: "1억 ~ 3억", min: 100000000, max: 300000000, count: 0, budget: 0, desc: "지자체 표준 GIS 기능보강" },
    { label: "3억 ~ 5억", min: 300000000, max: 500000000, count: 0, budget: 0, desc: "핵심 중소기업 타깃 프로젝트" }
  ];

  const monthMap = {};
  for (let m = 1; m <= 11; m++) {
    const key = `2026-${String(m).padStart(2, '0')}`;
    monthMap[key] = { month: key, label: `${m}월`, count: 0, budget: 0, under500Count: 0, under500Budget: 0 };
  }

  const catMap = {};
  const under500CatMap = {};
  const orgMap = {};
  const agencyMap = {};
  const under500AgencyMap = {};
  const contractMap = {};
  const under500ContractMap = {};
  const themeMap = {};
  const winnerMap = {};

  const budgetBuckets = [
    { label: "5천만 미만", min: 0, max: 50000000, count: 0, budget: 0 },
    { label: "5천만 ~ 1억", min: 50000000, max: 100000000, count: 0, budget: 0 },
    { label: "1억 ~ 3억", min: 100000000, max: 300000000, count: 0, budget: 0 },
    { label: "3억 ~ 5억", min: 300000000, max: 500000000, count: 0, budget: 0 },
    { label: "5억 이상", min: 500000000, max: Infinity, count: 0, budget: 0 }
  ];

  projects.forEach(p => {
    const budget = Number(p.assignBdgtAmt) || 0;
    totalBudget += budget;

    const isUnder500M = budget < 500000000;
    if (isUnder500M) {
      under500Count += 1;
      under500Budget += budget;
      if (budget < 100000000) under100Count += 1;
      if (budget < 50000000) under50Count += 1;

      // 5억 미만 세부 구간 집계
      for (const b of under500Buckets) {
        if (budget >= b.min && budget < b.max) {
          b.count += 1;
          b.budget += budget;
          break;
        }
      }

      // 5억 미만 카테고리
      const c = p.category || "기타";
      if (!under500CatMap[c]) under500CatMap[c] = { category: c, count: 0, budget: 0 };
      under500CatMap[c].count += 1;
      under500CatMap[c].budget += budget;

      // 5억 미만 발주기관
      const ag = p.dminsttNm || p.ntceInsttNm || "미상";
      if (!under500AgencyMap[ag]) under500AgencyMap[ag] = { agency: ag, count: 0, budget: 0, orgType: p.orgType };
      under500AgencyMap[ag].count += 1;
      under500AgencyMap[ag].budget += budget;

      // 5억 미만 계약방법
      const mthd = p.cntrctCnclsMthdNm || "기타";
      if (!under500ContractMap[mthd]) under500ContractMap[mthd] = { method: mthd, count: 0, budget: 0 };
      under500ContractMap[mthd].count += 1;
      under500ContractMap[mthd].budget += budget;
    }

    if (!maxBudgetProj || budget > maxBudgetProj.assignBdgtAmt) {
      maxBudgetProj = p;
    }

    // 월별 통계
    const dt = p.bidNtceDt ? p.bidNtceDt.substring(0, 7) : '기타';
    if (!monthMap[dt]) {
      monthMap[dt] = { month: dt, label: dt, count: 0, budget: 0, under500Count: 0, under500Budget: 0 };
    }
    monthMap[dt].count += 1;
    monthMap[dt].budget += budget;
    if (isUnder500M) {
      monthMap[dt].under500Count += 1;
      monthMap[dt].under500Budget += budget;
    }

    // 전체 카테고리
    const cat = p.category || "기타";
    if (!catMap[cat]) catMap[cat] = { category: cat, count: 0, budget: 0 };
    catMap[cat].count += 1;
    catMap[cat].budget += budget;

    // 기관유형
    const orgType = p.orgType || "기타";
    if (!orgMap[orgType]) orgMap[orgType] = { orgType, count: 0, budget: 0 };
    orgMap[orgType].count += 1;
    orgMap[orgType].budget += budget;

    // 발주/수요기관
    const agency = p.dminsttNm || p.ntceInsttNm || "미상";
    if (!agencyMap[agency]) agencyMap[agency] = { agency, count: 0, budget: 0, orgType };
    agencyMap[agency].count += 1;
    agencyMap[agency].budget += budget;

    // 계약방법
    const method = p.cntrctCnclsMthdNm || "기타";
    if (!contractMap[method]) contractMap[method] = { method, count: 0, budget: 0 };
    contractMap[method].count += 1;
    contractMap[method].budget += budget;

    // 전체 예산 구간
    for (const bucket of budgetBuckets) {
      if (budget >= bucket.min && (budget < bucket.max || bucket.max === Infinity)) {
        bucket.count += 1;
        bucket.budget += budget;
        break;
      }
    }

    // 테마 키워드
    if (Array.isArray(p.keyThemes)) {
      p.keyThemes.forEach(th => {
        if (!themeMap[th]) themeMap[th] = { theme: th, count: 0, budget: 0, isUnder500M };
        themeMap[th].count += 1;
        themeMap[th].budget += budget;
      });
    }

    // 낙찰 통계
    if (p.isSuccessBidded) {
      successCount += 1;
      const rateVal = Number(p.bidRate);
      if (rateVal && rateVal >= 50 && rateVal <= 110) {
        totalSuccRateSum += rateVal;
        succRateCount += 1;
      } else if (p.succBidAmt && budget > 0) {
        const rate = (p.succBidAmt / budget) * 100;
        totalSuccRateSum += rate;
        succRateCount += 1;
      }
      if (p.succBidCorp) {
        const winner = p.succBidCorp;
        if (!winnerMap[winner]) winnerMap[winner] = { winner, count: 0, totalWon: 0, under500Count: 0 };
        winnerMap[winner].count += 1;
        winnerMap[winner].totalWon += (p.succBidAmt || budget);
        if (isUnder500M) winnerMap[winner].under500Count += 1;
      }
    }
  });

  const avgBudget = totalCount > 0 ? Math.round(totalBudget / totalCount) : 0;
  const avgUnder500Budget = under500Count > 0 ? Math.round(under500Budget / under500Count) : 0;
  const avgSuccRate = succRateCount > 0 ? (totalSuccRateSum / succRateCount).toFixed(1) : 0;

  const monthly = Object.values(monthMap).sort((a, b) => a.month.localeCompare(b.month));

  const categories = Object.values(catMap).map(c => ({
    ...c,
    ratio: Number(((c.budget / (totalBudget || 1)) * 100).toFixed(1)),
    countRatio: Number(((c.count / totalCount) * 100).toFixed(1))
  })).sort((a, b) => b.budget - a.budget);

  const under500Categories = Object.values(under500CatMap).map(c => ({
    ...c,
    ratio: Number(((c.budget / (under500Budget || 1)) * 100).toFixed(1)),
    countRatio: Number(((c.count / under500Count) * 100).toFixed(1))
  })).sort((a, b) => b.count - a.count);

  const orgTypes = Object.values(orgMap).map(o => ({
    ...o,
    ratio: Number(((o.budget / (totalBudget || 1)) * 100).toFixed(1))
  })).sort((a, b) => b.budget - a.budget);

  const topAgenciesByCount = Object.values(agencyMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const topUnder500Agencies = Object.values(under500AgencyMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const contractMethods = Object.values(contractMap)
    .map(c => ({
      ...c,
      ratio: Number(((c.count / totalCount) * 100).toFixed(1))
    }))
    .sort((a, b) => b.count - a.count);

  const under500ContractMethods = Object.values(under500ContractMap)
    .map(c => ({
      ...c,
      ratio: Number(((c.count / under500Count) * 100).toFixed(1))
    }))
    .sort((a, b) => b.count - a.count);

  const topThemes = Object.values(themeMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 15);

  const topWinners = Object.values(winnerMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  return {
    summary: {
      totalCount,
      totalBudget,
      avgBudget,
      maxBudget: maxBudgetProj ? maxBudgetProj.assignBdgtAmt : 0,
      maxBudgetTitle: maxBudgetProj ? maxBudgetProj.bidNtceNm : '',
      successCount,
      pendingCount: totalCount - successCount,
      successRatio: Number(((successCount / totalCount) * 100).toFixed(1)),
      uniqueAgencies: Object.keys(agencyMap).length
    },
    // 5억 미만 중점 분석 세그먼트
    under500M: {
      totalCount: under500Count,
      totalBudget: under500Budget,
      avgBudget: avgUnder500Budget,
      countRatio: Number(((under500Count / totalCount) * 100).toFixed(1)),
      budgetRatio: Number(((under500Budget / totalBudget) * 100).toFixed(1)),
      under100Count,
      under50Count,
      buckets: under500Buckets,
      categories: under500Categories,
      topAgencies: topUnder500Agencies,
      contractMethods: under500ContractMethods
    },
    monthly,
    categories,
    orgTypes,
    topAgencies: {
      byBudget: Object.values(agencyMap).sort((a, b) => b.budget - a.budget).slice(0, 10),
      byCount: topAgenciesByCount,
      under500M: topUnder500Agencies
    },
    budgetRanges: budgetBuckets,
    contractMethods,
    topThemes,
    winStats: {
      awardedCount: successCount,
      avgSuccRate: Number(avgSuccRate),
      topWinners
    }
  };
}

module.exports = { calculateAnalytics };
